<label for='title' class='form-label'>Heading Text:</label>
<input type='text' name='title' value='{{$link_title}}' class='form-control' />


